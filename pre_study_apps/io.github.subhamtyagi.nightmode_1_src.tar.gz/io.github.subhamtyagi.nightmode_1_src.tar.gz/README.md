# Night mode tile

 - Get a Tile to quickly enable night mode on your devices.
 - Easy to use
 
### Get it on F-droid

### [MIT License](./LICENSE) 
        MIT Copyright 2019 @ Shubham Tyagi
